import rclpy
from rclpy.node import Node
from sensor_msgs.msg import JointState

class master_state_node(Node):

    def __init__(self):
        super().__init__('master_state_node')
        self.get_logger().info('Master State Node')


        self.get_state_subscription = self.create_subscription(
            JointState,
            '/masterL/joint_states',
            self.get_state_callback,
            10
        )

        self.get_state_subscription = self.create_subscription(
            JointState,
            '/masterR/joint_states',
            self.get_state_callback,
            10
        )

        self.send_state_publisher = self.create_publisher(
            JointState,
            'controller/master_state_L',
            10
        )

        self.send_state_publisher = self.create_publisher(
            JointState,
            'controller/master_state_R',
            10
        )
    
    def get_state_callback(self,msg:JointState):
        master_state_msg = msg
        if len(master_state_msg.position)>0:
            master_state_msg.position.pop(-4)
        if len(master_state_msg.velocity)>0:
            master_state_msg.velocity.pop(-4)
        if len(master_state_msg.effort)>0:
            master_state_msg.effort.pop(-4)
        master_state_msg.name.pop(-4)

        self.send_state_publisher.publish(master_state_msg)

        return

def main(args=None):
    rclpy.init(args=args)
    node = master_state_node()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__=="__main__":
    main()

