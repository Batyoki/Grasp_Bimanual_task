import rclpy
from rclpy.node import Node
from sensor_msgs.msg import JointState

class slave_state_node(Node):

    def __init__(self):
        super().__init__('slave_state_node')
        self.get_logger().info('Slave State Node')


        self.get_state_subscription = self.create_subscription(
            JointState,
            '/slaveL/joint_states',
            self.get_state_callback,
            10
        )

        self.get_state_subscription = self.create_subscription(
            JointState,
            '/slaveR/joint_states',
            self.get_state_callback,
            10
        )

        self.send_state_publisher = self.create_publisher(
            JointState,
            'controller/slave_state_L',
            10
        )

        self.send_state_publisher = self.create_publisher(
            JointState,
            'controller/slave_state_R',
            10
        )
    
    def get_state_callback(self,msg:JointState):
        slave_state_msg = msg
        self.send_state_publisher.publish(slave_state_msg)
        return

def main(args=None):
    rclpy.init(args=args)
    node = slave_state_node()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__=="__main__":
    main()
    
