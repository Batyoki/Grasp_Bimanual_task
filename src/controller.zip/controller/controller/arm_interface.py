"""
arm_interface.py
----------------
Abstraction layer for the two robot types used in the bilateral
teleoperation system:

  Master: ViperX 300s   (6-DOF physical, 5-DOF with wrist-roll locked)
  Slave:  ReactorX 150  (5-DOF physical)

Both arms share the same 5-DOF active joint space after constraining
the wrist-roll joint (joint index 5, 0-indexed).

Motor Sensor Availability
--------------------------
The ONLY sensors available are the Dynamixel motor's internal current
(and hence torque) readings, plus joint position from encoders.
There are NO external F/T sensors.

Torque Estimation
-----------------
  tau_measured = kt * I_measured  (per joint)
  where kt is the motor torque constant.

  The net EXTERNAL torque (due to contact) is estimated as:
  tau_ext = tau_measured - (M * ddq + C + G)

  Since ddq must be numerically differentiated from encoder data,
  apply a low-pass filter to avoid amplifying noise.

Mass / Coriolis / Gravity
--------------------------
Dynamics are estimated using pinochio

"""

import numpy as np
from dataclasses import dataclass, field
from typing import Optional
import json


# ---------------------------------------------------------------------------
# Joint limits (radians) — adjust to match your hardware config
# ---------------------------------------------------------------------------

# <<USER: Verify these limits against your ViperX300s URDF / spec sheet>>
VIPERX300S_Q_MIN = np.array([-180,-101,-101,-107,-180])*(np.pi/180)
VIPERX300S_Q_MAX  = np.array([180,101,92,130,180,180])*(np.pi/180)
# NOT Verified
VIPERX300S_DQ_MAX = np.array([ 3.0,   3.0,   3.0,   3.0,   3.0])   # rad/s
VIPERX300S_TAU_MAX = np.array([8.0,  10.0,   8.0,   5.0,   3.0])    # N·m

# <<USER: Verify these limits against your ReactorX150 URDF / spec sheet>>
REACTORX150_Q_MIN  = np.array([-180,-106,-102,-100,-180])*(np.pi/180)
REACTORX150_Q_MAX  = np.array([180,100,95,123,180])*(np.pi/180)
# NOT VERIFIED
REACTORX150_DQ_MAX = np.array([ 3.0,   3.0,   3.0,   3.0,   3.0])
REACTORX150_TAU_MAX = np.array([5.0,   6.0,   5.0,   3.5,   2.5])

# ---------------------------------------------------------------------------
# Motor torque constants (Nm/A) for each joint's Dynamixel motor
# <<USER: Fill in actual kt values from your Dynamixel motor spec sheets>>
# For XM430 series: kt ~ 2.0–2.5 Nm/A (depends on winding)
# For XL430 / XC430 series: kt ~ 1.5–1.8 Nm/A
# ---------------------------------------------------------------------------
VIPERX300S_KT   = np.array([2.1, 2.1, 2.1, 1.8, 1.5])  # <<USER: verify>>
REACTORX150_KT  = np.array([1.8, 1.8, 1.8, 1.5, 1.3])  # <<USER: verify>>

# Wrist-roll joint index (0-based) that is LOCKED / excluded
WRIST_ROLL_IDX = 5   # joint6 in full 6-DOF chain; not used in 5-DOF model
ACTIVE_JOINTS  = [0, 1, 2, 3, 4]  # waist, shoulder, elbow, forearm_roll, pitch


@dataclass
class ArmState:
    """Snapshot of a single arm's sensed state at one time step."""
    q:          np.ndarray           # Joint positions  (5,)
    dq:         np.ndarray           # Joint velocities (5,) — numerical diff
    tau_motor:  np.ndarray           # Motor torques from current sensing (5,)
    tau_ext:    np.ndarray           # Estimated external contact torques (5,)
    timestamp:  float = 0.0          # ROS time in seconds


class ArmDynamics:
    """
    Holds and evaluates joint-space dynamics for one arm.

    The user must provide callables (or pre-computed matrices) for:
      M(q)  — inertia matrix
      C(q, dq) — Coriolis/centrifuge vector
      G(q)  — gravity vector

    These can be generated from:
      - roboticstoolbox  (DHRobot.inertia / .coriolis / .gravload)
      - ikpy + custom differentiator
      - pinocchio library (recommended for real-time use)
      - a symbolic model exported from Matlab/Simulink

    <<USER: Replace lambda stubs below with your actual dynamic model>>
    """

    def __init__(self, arm_type: str):
        assert arm_type in ("viperx300s", "reactorx150")
        self.arm_type = "vx300s" if arm_type == "viperx300s" else "rx150"
        self.n = 5  # active DOF

        json_data=None
        with open(r'/home/sp/Desktop/6th_Semester/RnD/ws/src/controller/controller/data.json','r') as f:
            json_data = json.load(f)
        
        self.M_fn  = lambda q:       json_data[arm_type]['M']          
        self.C_fn  = lambda q, dq:   json_data[arm_type]['C']
        self.G_fn  = lambda q:       json_data[arm_type]['g']     

    def get_M(self, q: np.ndarray) -> np.ndarray:
        return self.M_fn(q)

    def get_C(self, q: np.ndarray, dq: np.ndarray) -> np.ndarray:
        return self.C_fn(q, dq)

    def get_G(self, q: np.ndarray) -> np.ndarray:
        return self.G_fn(q)


class ArmInterface:
    """
    Wraps a physical arm's state estimation and torque sensing.

    Responsibilities
    ----------------
    1. Read joint positions from Dynamixel encoders (via ROS topic).
    2. Read motor current → estimate joint torque.
    3. Numerically differentiate joint positions → velocity.
    4. Estimate external torques by subtracting model torques.
    5. Apply low-pass filters to all noisy signals.
    """

    def __init__(
        self,
        arm_type: str,                # "viperx300s" or "reactorx150"
        dynamics: ArmDynamics,
        dt: float,
        filter_alpha: float = 0.3,   # 1st-order IIR smoothing coeff
    ):
        assert arm_type in ("viperx300s", "reactorx150")
        self.arm_type = "vx300s" if arm_type == "viperx300s" else "rx150"
        self.dynamics = dynamics
        self.dt = dt
        self.alpha = filter_alpha
        self.n = 5

        # Motor torque constants
        self.kt = (VIPERX300S_KT if arm_type == "viperx300s"
                   else REACTORX150_KT)

        # Internal state buffers
        self._q_prev:   Optional[np.ndarray] = None
        self._dq_filt:  np.ndarray = np.zeros(self.n)
        self._tau_filt: np.ndarray = np.zeros(self.n)

    # ------------------------------------------------------------------
    # Raw sensor ingestion
    # ------------------------------------------------------------------

    def update(
        self,
        q_raw: np.ndarray,          # Raw encoder positions (5,)  [rad]
        current_raw: np.ndarray,    # Raw motor currents   (5,)  [A]
    ) -> ArmState:
        """
        Process one sensor snapshot and return an ArmState.

        Call this at each control loop iteration.
        """
        q = q_raw.copy()

        # --- Velocity: numerical differentiation + IIR low-pass -------
        if self._q_prev is None:
            dq_raw = np.zeros(self.n)
        else:
            dq_raw = (q - self._q_prev) / self.dt

        # IIR: dq_filt[k] = alpha*dq_raw + (1-alpha)*dq_filt[k-1] #low pass filter
        self._dq_filt = self.alpha * dq_raw + (1 - self.alpha) * self._dq_filt
        self._q_prev  = q.copy()

        # --- Torque from current: tau = kt * I -------------------------
        # <<USER: Verify sign conventions for your Dynamixel setup.
        #         Some joints may need sign flip depending on mounting.>>
        tau_raw = self.kt * current_raw
        self._tau_filt = (self.alpha * tau_raw
                          + (1 - self.alpha) * self._tau_filt)

        # --- External torque estimation --------------------------------
        # tau_measured = M*ddq + C + G + tau_ext
        # => tau_ext = tau_measured - M*ddq - C - G
        #
        # We skip ddq (double diff is too noisy without filtering) and
        # approximate tau_ext as the residual between measured torque
        # and the gravity + Coriolis model only.
        # For better accuracy: add a state observer / Kalman filter here.
        # <<USER: If you implement ddq estimation, uncomment M*ddq term>>

        M = self.dynamics.get_M(q)
        C = self.dynamics.get_C(q, self._dq_filt)
        G = self.dynamics.get_G(q)

        tau_model = C + G   # + M @ ddq_estimated  (<<USER: add if available>>)
        tau_ext   = self._tau_filt - tau_model

        return ArmState(
            q=q,
            dq=self._dq_filt.copy(),
            tau_motor=self._tau_filt.copy(),
            tau_ext=tau_ext,
        )

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @property
    def q_limits(self):
        if self.arm_type == "viperx300s":
            return VIPERX300S_Q_MIN, VIPERX300S_Q_MAX
        return REACTORX150_Q_MIN, REACTORX150_Q_MAX

    @property
    def tau_limits(self):
        if self.arm_type == "viperx300s":
            return -VIPERX300S_TAU_MAX, VIPERX300S_TAU_MAX
        return -REACTORX150_TAU_MAX, REACTORX150_TAU_MAX

    @property
    def dq_limits(self):
        if self.arm_type == "viperx300s":
            return -VIPERX300S_DQ_MAX, VIPERX300S_DQ_MAX
        return -REACTORX150_DQ_MAX, REACTORX150_DQ_MAX