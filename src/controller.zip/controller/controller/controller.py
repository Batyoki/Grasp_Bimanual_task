
"""
bilateral_teleop_node.py
------------------------
ROS2 node implementing the unified bimanual bilateral teleoperation
architecture for:
 
  Master: 2 x ViperX300s  (left + right, 5-DOF each with wrist-roll locked)
  Slave:  2 x ReactorX150 (left + right, 5-DOF each with wrist-roll locked)
 
Node Architecture
-----------------
 
  ┌─────────────────────────────────────────────────────────────┐
  │                 BimanualTeleopNode                          │
  │                                                             │
  │  ┌──────────────────┐     ┌──────────────────┐              │
  │  │  Left MISA+MPC   │     │  Right MISA+MPC  │              │
  │  │  Controller      │     │  Controller      │              │
  │  └──────────────────┘     └──────────────────┘              │
  │         │                         │                         │
  │   MasterL ↔ SlaveL          MasterR ↔ SlaveR                │
  │                                                             │
  │  Topics subscribed:                                         │
  │    /viper_left/joint_states    (sensor_msgs/JointState)     │
  │    /viper_right/joint_states                                │
  │    /reactor_left/joint_states                               │
  │    /reactor_right/joint_states                              │
  │    /viper_left/joint_currents  (std_msgs/Float64MultiArray) │
  │    /viper_right/joint_currents                              │
  │    /reactor_left/joint_currents                             │
  │    /reactor_right/joint_currents                            │
  │    /teleop/enable              (std_msgs/Bool)              │
  │                                                             │
  │  Topics published:                                          │
  │    /viper_left/cmd_torque      (std_msgs/Float64MultiArray) │
  │    /viper_right/cmd_torque                                  │
  │    /reactor_left/cmd_position  (std_msgs/Float64MultiArray) │
  │    /reactor_right/cmd_position                              │
  │    /teleop/diagnostics         (std_msgs/String)  [10 Hz]   │
  └─────────────────────────────────────────────────────────────┘
 
Control Mode Switching
----------------------
  The node supports the four-channel unified architecture.
  Mode selection is via ROS parameter "control_mode":
    "MISA"  — Master Impedance / Slave Admittance  (default)
    "MASA"  — Master Admittance / Slave Admittance
    "MASI"  — Master Admittance / Slave Impedance
    "MISI"  — Master Impedance / Slave Impedance
 
  <<USER: Only MISA is fully implemented here.  To add other modes,
          implement the respective control law in misa_mpc_controller.py
          and dispatch based on self.control_mode below.>>
 
Safety
------
  - Torque commands are clamped to hardware limits before publishing.
  - If any arm's joint state goes stale (> 500 ms), torque commands
    drop to gravity-compensation-only.
  - An enable/disable topic allows the operator to kill the loop safely.
"""


import rclpy
from rclpy.node import Node
from sensor_msgs.msg import JointState
from std_msgs.msg import Float64MultiArray, Bool, String
import json
import numpy as np
# from arm_interface import *
from .arm_interface import (
    VIPERX300S_DQ_MAX,VIPERX300S_KT,VIPERX300S_Q_MAX,VIPERX300S_Q_MIN,VIPERX300S_TAU_MAX,
    REACTORX150_DQ_MAX,REACTORX150_KT,REACTORX150_Q_MAX,REACTORX150_Q_MIN,REACTORX150_TAU_MAX,
    ArmDynamics, ArmInterface, ArmState
)
from .misa_mpc_controller import MISAController,MISAParams
from rclpy.callback_groups import ReentrantCallbackGroup
import time


class controller(Node):

    def __init__(self):
        super().__init__('controller')
        self.get_logger().info('Controller node has started')

        # ROS2 PARAMETERS
        self.declare_parameter("control_mode","MISA")
        self.declare_parameter("loop_rate_hz",  100.0)
        self.declare_parameter("mpc_horizon",   10)
        self.declare_parameter("state_timeout_s", 0.5)


        json_data=None
        with open(r'/home/sp/Desktop/6th_Semester/RnD/ws/src/controller/controller/data.json','r') as f:
            json_data = json.load(f)
        
        self.n_joints = 5
        
        self.Mm = np.array(json_data['vx300s']['M'])
        self.Ms = np.array(json_data['rx150']['M'])

        self.Cm = np.array(json_data['vx300s']['C'])
        self.Cs = np.array(json_data['rx150']['C'])
        


        # Impedance gains (master) — diagonal entries per joint
        self.declare_parameter("master_Mmd_diag",self.Mm.flatten().tolist())
        # self.get_logger().warn(f"TRING NOW")
        # self.get_logger().warn(f"TRING TO ACCESS THE MASTER MMD PARAMETER {self.get_parameter('master_Mmd_diag').value}")
        self.declare_parameter("master_Dmd_diag", [5.0, 8.0, 5.0, 3.0, 2.0])
        self.declare_parameter("master_Kmd_diag", [10.0,15.0,10.0, 5.0, 3.0])

        # Admittance gains (slave)
        self.declare_parameter("slave_Msd_diag", self.Ms.flatten().tolist())
        self.declare_parameter("slave_Dsd_diag",  [4.0, 6.0, 4.0, 2.5, 1.5])
        self.declare_parameter("slave_Ksd_diag",  [8.0,12.0, 8.0, 4.0, 2.5])

        # Four-channel coupling gains
        self.declare_parameter("kof", 0.8)   # slave→master force coupling
        self.declare_parameter("ksf", 0.2)   # local master force coupling
        self.declare_parameter("kom", 0.8)   # slave→master position coupling
        self.declare_parameter("ksm", 0.2)   # local master position coupling


        self.control_mode = self.get_parameter("control_mode").value
        self.frequency = self.get_parameter("loop_rate_hz").value
        self.dt = 1.0/self.frequency
        self.timeout = self.get_parameter("state_timeout_s").value

        self.qm = np.zeros(5)
        self.qs = np.zeros(5)

        self.qdotm = np.zeros(5)
        self.qdots = np.zeros(5)


        self.master_L_dynamics = ArmDynamics("viperx300s")
        self.master_R_dynamics = ArmDynamics("viperx300s")

        self.slave_L_dynamics = ArmDynamics("reactorx150")
        self.slave_R_dynamics = ArmDynamics("reactorx150")

        filter_alpha = 0.3
        self.master_L_interface = ArmInterface("viperx300s",self.master_L_dynamics,self.dt,filter_alpha)
        self.master_R_interface = ArmInterface("viperx300s",self.master_R_dynamics,self.dt,filter_alpha)
        self.slave_L_interface = ArmInterface("reactorx150",self.slave_L_dynamics,self.dt,filter_alpha)
        self.slave_R_interface = ArmInterface("reactorx150",self.slave_R_dynamics,self.dt,filter_alpha)


        params = self._build_params()
        ctrl_kwargs = dict(
            params=params,
            q_master_min=VIPERX300S_Q_MIN,
            q_master_max=VIPERX300S_Q_MAX,
            q_slave_min=REACTORX150_Q_MIN,
            q_slave_max=REACTORX150_Q_MAX,
            tau_master_max=VIPERX300S_TAU_MAX,
            tau_slave_max=REACTORX150_TAU_MAX,
            dq_master_max=VIPERX300S_DQ_MAX,
            dq_slave_max=REACTORX150_DQ_MAX,
        )

        self.ctrl_L = MISAController(
            master_dynamics=self.master_L_dynamics,
            slave_dynamics=self.slave_L_dynamics,
            **ctrl_kwargs
        )

        self.ctrl_R = MISAController(
            master_dynamics=self.master_R_dynamics,
            slave_dynamics=self.slave_R_dynamics,
            **ctrl_kwargs,
        )


        # ------------------------------------------------------------------
        # State buffers (raw sensor data)
        # ------------------------------------------------------------------
        self._raw = {
            "master_L_q": None,  "master_L_I": None,  "master_L_t": 0.0,
            "master_R_q": None,  "master_R_I": None,  "master_R_t": 0.0,
            "slave_L_q":  None,  "slave_L_I":  None,  "slave_L_t":  0.0,
            "slave_R_q":  None,  "slave_R_I":  None,  "slave_R_t":  0.0,
        }
        self.enabled = True


        #SUBSCRIPTIONS

        cbg = ReentrantCallbackGroup()

        
        self.master_state_subscription_L = self.create_subscription(
            JointState,
            'controller/master_state_L',
            lambda msg:self.master_state_callback(msg,"L"),
            10,
            callback_group=cbg
        )

        self.master_state_subscription_R = self.create_subscription(
            JointState,
            'controller/master_state_R',
            lambda msg:self.master_state_callback(msg,"R"),
            10,
            callback_group=cbg
        )

        self.slave_state_subscription_L = self.create_subscription(
            JointState,
            'controller/slave_state_L',
            lambda msg:self.slave_state_callback(msg,"L"),
            10,
            callback_group=cbg
        )

        self.slave_state_subscription_R = self.create_subscription(
            JointState,
            'controller/slave_state_R',
            lambda msg:self.slave_state_callback(msg,"R"),
            10,
            callback_group=cbg
        )

        self.create_subscription(Bool, "/teleop/enable",
            self._enable_cb, 10, callback_group=cbg)


        # PUBLISHERS

        self.tau_master_L_pub = self.create_publisher(
            Float64MultiArray,
            'controller/torque_master_L',
            10
        )
        self.tau_master_R_pub = self.create_publisher(
            Float64MultiArray,
            'controller/torque_master_R',
            10
        )
        self.q_slave_L_pub = self.create_publisher(
            Float64MultiArray,
            'controller/torque_slave_L',
            10
        )
        self.q_slave_R_pub = self.create_publisher(
            Float64MultiArray,
            'controller/torque_slave_R',
            10
        )

        self.diagnostics_pub = self.create_publisher(
            String,
            'controller/teleop/diagnostics',
            10
        )


        self.control_timer = self.create_timer(self.dt, self.control_loop,callback_group=cbg)

        self.diagnostics_timer = self.create_timer(0.1, self.publish_diagnostics,callback_group=cbg)


        self._loop_times = []


        self.get_logger().info(f"""
            Controller Node initialized
            Control Mode : {self.control_mode}
            dt : {self.dt*1000:.1f} ms
            MPC params = {ctrl_kwargs}
        """)





    def _enable_cb(self,msg):
        self.enabled = msg.data
        state = "enabled" if self.enabled else "disabled"
        self.get_logger().info(f"Teleoperation {state} via /teleop/enable topic")

    def publish_diagnostics(self):
        if not self._loop_times:
            return
        
        avg_ms = np.mean(self._loop_times)*1000
        max_ms = np.max(self._loop_times)*1000

        info = {
            "enabled" : self.enabled,
            "control_mode" : self.control_mode,
            "Loop average ms " : avg_ms,
            "Loop max ms" : max_ms,
            "master_L_age_ms": round(
                (self.get_clock().now().nanoseconds*1e-9 - self._raw["master_L_t"])*1000, 1),
            "master_R_age_ms": round(
                (self.get_clock().now().nanoseconds*1e-9 - self._raw["master_R_t"])*1000, 1),
        }

        msg=String()
        msg.data = json.dumps(info)
        self.diagnostics_pub.publish(msg)

    

    def _build_params(self) -> MISAParams:
        get = lambda name: np.array(self.get_parameter(name).value, dtype=float)
 
        return MISAParams(
            n_joints = 5,
            N  = self.get_parameter("mpc_horizon").value,
            dt = self.dt,
            Mmd = np.array(get("master_Mmd_diag")).reshape(9,9),
            Dmd = np.diag(get("master_Dmd_diag"),5),
            Kmd = np.diag(get("master_Kmd_diag"),5),
            Msd = np.array(get("slave_Msd_diag")).reshape(8,8),
            Dsd = np.diag(get("slave_Dsd_diag"),5),
            Ksd = np.diag(get("slave_Ksd_diag"),5),
            kof = float(self.get_parameter("kof").value),
            ksf = float(self.get_parameter("ksf").value),
            kom = float(self.get_parameter("kom").value),
            ksm = float(self.get_parameter("ksm").value),
        )

    def control_loop(self):
        if not self.enabled:
            self.get_logger().warn("Teleoperation Loop is disabled.")
            return

        t_start = time.perf_counter()
        now = self.get_clock().now().nanoseconds * 1e-9


        # Check for data freshness and ignore if any arms state is too old
        for arm_key in ["master_L", "master_R", "slave_L", "slave_R"]:
            age = now - self._raw.get(f"{arm_key}_t", 0.0)
            if age > self.timeout:
                self.get_logger().warn(
                    f"[{arm_key}] stale state ({age*1000:.0f}ms) — skipping cycle")
                return

        # Check all data present
        for arm_key in ["master_L", "master_R", "slave_L", "slave_R"]:
            if (self._raw.get(f"{arm_key}_q") is None or
                    self._raw.get(f"{arm_key}_I") is None):
                self.get_logger().info(f"Waiting for {arm_key} data...")
                return

        # Process arm states 

        master_L_state = self.master_L_interface.update(
            self._raw['master_L_q'], self._raw['master_L_I'])
        
        master_R_state = self.master_R_interface.update(
            self._raw['master_R_q'], self._raw['master_R_I'])
        
        slave_L_state = self.slave_L_interface.update(
            self._raw['slave_L_q'],self._raw['slave_L_I']
        )
        slave_R_state = self.slave_R_interface.update(
            self._raw['slave_R_q'],self._raw['slave_R_I']
        )



        # Running MPC Controller

        # Right Pair
        tau_master_L , q_slave_left =  self.ctrl_L.step(master_L_state, slave_L_state)
        # Left Pair
        tau_master_R, q_slave_right = self.ctrl_R.step(master_R_state, slave_R_state)



        # SAFETY CLAMPING
        tau_master_L = np.clip(tau_master_L, -VIPERX300S_TAU_MAX, VIPERX300S_TAU_MAX)
        tau_master_R = np.clip(tau_master_R, -VIPERX300S_TAU_MAX, VIPERX300S_TAU_MAX)

        q_slave_left = np.clip(q_slave_left, REACTORX150_Q_MIN, REACTORX150_Q_MAX)
        q_slave_right = np.clip(q_slave_right, REACTORX150_Q_MIN, REACTORX150_Q_MAX)


        # PUBLISHING RESULTS FROM THE CONTROL LOOP

        self.tau_master_L_pub.publish(self._f64(tau_master_L))
        self.tau_master_R_pub.publish(self._f64(tau_master_R))

        self.q_slave_L_pub.publish(self._f64(q_slave_left))
        self.q_slave_R_pub.publish(self._f64(q_slave_right))


        self._loop_times.append(time.perf_counter() - t_start)
        if(len(self._loop_times)>100):
            self._loop_times.pop(0)
        

        return
        
    def master_state_callback(self,msg:JointState,arm:str):
        
        arm = "master_L" if "L" == arm else "master_R"
        q_raw = np.array(msg.position)
        I_raw = np.array(msg.effort)
        t = self.get_clock().now().nanoseconds * 1e-9
        self._raw[f"{arm}_q"] = q_raw
        self._raw[f"{arm}_I"] = I_raw
        self._raw[f"{arm}_t"] = t

    def slave_state_callback(self,msg:JointState,arm:str):
        arm = "slave_L" if "L" == arm else "slave_R"
        q_raw = np.array(msg.position)
        I_raw = np.array(msg.effort)
        t = self.get_clock().now().nanoseconds * 1e-9
        self._raw[f"{arm}_q"] = q_raw
        self._raw[f"{arm}_I"] = I_raw
        self._raw[f"{arm}_t"] = t
    
    @staticmethod
    def _f64(arr: np.ndarray)->Float64MultiArray:
        msg = Float64MultiArray()
        msg.data = arr.tolist()
        return msg

        



def main(args=None):
    rclpy.init(args=args)
    node = controller()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__=='__main__':
    main()

